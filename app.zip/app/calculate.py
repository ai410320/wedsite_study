from flask import Flask, request
from flask import render_template
import os

app = Flask(__name__)

@app.route('/')
def test():

    return render_template('test.html')

@app.route('/mkao')
def test_mkao():
    return render_template('mkao.html');

@app.route('/testForm', methods=['POST'])
def testForm():
    type = request.form.get('domain_type');
    name = request.form.get('domain_name');
    return 'hello '+type + name

if __name__ == '__main__':
    app.run(debug=True, port=5500, host='10.17.63.10')
