$(document).ready(function(){
	var data ={};
	$("button[class='submit_button']").click(function(){
		//console.log('UUU');
		//data.domain_type = $("input[domain_type='type']").val();
		//data.domain_name = $("input[domain_name='name']").val();
		$.ajax({
			type: 'POST',
			url:"/testForm",
			data:$('form').serialize(),   
			success:function(data){ //成功的話，得到訊息
				console.log('Success');
			}
		});
	});
  });
